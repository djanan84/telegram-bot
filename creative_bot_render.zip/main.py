import telebot
from flask import Flask, request
import os

API_TOKEN = '8113696153:AAExR72dONgxVD4Ht_4aE4xx-fTFyoCZlnw'
bot = telebot.TeleBot(API_TOKEN)
app = Flask(__name__)

@app.route('/' + API_TOKEN, methods=['POST'])
def getMessage():
    bot.process_new_updates([telebot.types.Update.de_json(request.stream.read().decode("utf-8"))])
    return "!", 200

@app.route("/")
def webhook():
    bot.remove_webhook()
    bot.set_webhook(url='https://creative-bot-render.onrender.com/' + API_TOKEN)
    return "Webhook set", 200

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.send_message(message.chat.id, "👋 Привет! Я креативный бот. Я могу дать тебе интересные задания для вдохновения, творчества и прокачки твоих визуальных навыков. Напиши /idea — и начнём!")

@bot.message_handler(commands=['idea'])
def send_idea(message):
    import random
    ideas = [
        "✏️ Нарисуй визитку для художника, который рисует только чёрным карандашом. Представь, что у него выставка в старом доме.",
        "🎨 Придумай логотип для кофейни в татарском стиле. Используй орнаменты, но не переборщи.",
        "📦 Представь упаковку для косметики, вдохновлённой лесами средней полосы. Что на ней?",
        "🧵 Создай афишу для выставки, посвящённой ручному ткачеству народов Кавказа.",
        "📸 Придумай серию фотографий на тему 'память места'. Что бы ты снял?",
        "🔤 Подумай над алфавитом, вдохновлённым славянской мифологией. Какие формы букв?",
        "🎭 Нарисуй логотип для театра, который ставит только сказки.",
        "🌿 Сфантазируй дизайн упаковки мёда, сделанного по старинным рецептам в горах."
    ]
    bot.send_message(message.chat.id, random.choice(ideas))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get('PORT', 5000)))
