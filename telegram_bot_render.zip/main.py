from flask import Flask, request
import telebot
import random
import os

TOKEN = os.environ.get("BOT_TOKEN")
bot = telebot.TeleBot(TOKEN)

app = Flask(__name__)

visitka_tasks = [
    "🌿 Визитка для экологичного бренда косметики с зелёными акцентами...",
    "🎩 Винтажная визитка барбершопа с элементами ретро...",
    "⚖️ Минималистичная визитка для юриста в стиле black & white...",
    "📸 Визитка свадебного фотографа, изящная, с лёгким золотом...",
    "🪵 Визитка мастера мебели в крафтовом стиле, с текстурой дерева..."
]

logo_tasks = [
    "🍃 Логотип бренда одежды из вторсырья с листьями...",
    "☕ Логотип сети грузинских кафе с элементами орнамента...",
    "💧 Логотип минеральной воды с каплей и горами...",
    "🎭 Логотип фестиваля современной культуры...",
    "🎙️ Логотип подкаста о кино в виде микрофона и киноленты..."
]

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.send_message(message.chat.id,
        "👋 Привет! Я креативный помощник для дизайнеров. Напиши /визитка или /логотип, и я пришлю тебе вдохновляющее задание!")

@bot.message_handler(commands=['визитка'])
def send_visitka(message):
    task = random.choice(visitka_tasks)
    bot.send_message(message.chat.id, task)

@bot.message_handler(commands=['логотип'])
def send_logo(message):
    task = random.choice(logo_tasks)
    bot.send_message(message.chat.id, task)

@app.route('/' + TOKEN, methods=['POST'])
def webhook():
    bot.process_new_updates([telebot.types.Update.de_json(request.stream.read().decode("utf-8"))])
    return 'OK', 200

@app.route('/')
def home():
    return "Бот работает!"

if __name__ == "__main__":
    bot.remove_webhook()
    bot.set_webhook(url=os.environ.get("WEBHOOK_URL") + TOKEN)
    app.run(host="0.0.0.0", port=int(os.environ.get('PORT', 5000)))